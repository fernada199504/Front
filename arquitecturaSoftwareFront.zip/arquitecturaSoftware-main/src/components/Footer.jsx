export default function Footer(){
    return(
        <div className="flex justify-center items-center p-2 flex-col bg-sky-500 mt-4 ">
            <p>Talento tech</p>
            <p>Desarrollado por Julian Cristancho</p>
        </div>
    )
}